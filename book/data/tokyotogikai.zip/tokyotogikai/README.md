# README

[東京都統計年鑑 令和4年 22　選挙・職員 22-4  選挙区，会派別都議会議員数 （令和5年10月16日）](https://www.toukei.metro.tokyo.lg.jp/tnenkan/2022/tn22q3i022.htm)を加工し作成

> [提供機関の利用規約](https://www.toukei.metro.tokyo.lg.jp/homepage/site-policy.htm)